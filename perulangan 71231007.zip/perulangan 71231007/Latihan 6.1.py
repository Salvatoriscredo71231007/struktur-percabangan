def perkalian(a, b):  ##Fungsi perkalian menggunakan penjumlahan##
  return a * b ## Hasil perkalian Bilangan pertama (6,5) dan Bilangan (7,10)##

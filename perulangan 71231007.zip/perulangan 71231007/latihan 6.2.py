def ganjil(bawah, atas):   ##Menampilkan deret bilangan ganjil##
  if bawah < atas:         ##bawah: Batas bawah deret dan atas: Batas atas deret##
    deret = [str(i) for i in range(bawah + 1, atas + 1, 2)]
  else:
    deret = [str(i) for i in range(bawah - 1, atas - 1, -2)]
  return ", ".join(deret)        ## Deret bilangan ganjil dalam bentuk string##
def hitung_ips(jumlah_mk, nilai_mk):  ##Menghitung nilai Indeks Prestasi Semester##
  total_sks = jumlah_mk * 3           ##jumlah_mk: Jumlah mata kuliah##
  total_bobot = 0
  for nilai in nilai_mk:              ## nilai_mk: List nilai mata kuliah (A, B, C, D).##
    if nilai == "A":          
      total_bobot += 4 * 3
    elif nilai == "B\\\\\\\\\\\\\\\\\\\\":
      total_bobot += 3 * 3
    elif nilai == "C":
      total_bobot += 2 * 3
    elif nilai == "D":
      total_bobot += 1 * 3
  return total_bobot / total_sks  ## Returns: Nilai Indeks Prestasi Semester##










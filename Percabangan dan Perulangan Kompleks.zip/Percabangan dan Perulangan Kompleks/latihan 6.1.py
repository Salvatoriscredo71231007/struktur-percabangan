def is_prima(n):
  """Mengecek apakah bilangan prima"""
  if n <= 1:
    return False
  for i in range(2, int(n**0.5) + 1):
    if n % i == 0:
      return False
  return True


def prima_terdekat(n):
  """Mencari bilangan prima terdekat kurang dari n"""
  for i in range(n - 1, 1, -1):
    if is_prima(i):
      return i


n = int(input("Masukkan bilangan: "))
prima = prima_terdekat(n)
print(f"Bilangan prima terdekat kurang dari {n} adalah {prima}")
def deret(n):
  """Menampilkan deret"""
  for i in range(n, 0, -1):
    for j in range(i, 0, -1):
      print(j, end=" ")
    print()


n = int(input("Masukkan nilai n: "))
deret(n)